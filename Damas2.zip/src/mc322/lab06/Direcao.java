package mc322.lab06;

public enum Direcao {
    NO, NE, SE, SO;
}