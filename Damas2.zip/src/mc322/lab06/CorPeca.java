package mc322.lab06;

public enum CorPeca {
    BRANCA, PRETA;
}