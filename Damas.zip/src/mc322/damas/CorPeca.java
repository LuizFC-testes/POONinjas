package mc322.damas;

public enum CorPeca {
    BRANCA, VERMELHA;
}