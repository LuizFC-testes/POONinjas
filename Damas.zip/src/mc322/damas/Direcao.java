package mc322.damas;

public enum Direcao {
    NO, NE, SE, SO;
}