package mc322.damas;

public class AppDamas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
